package vn.fujinet.sample.constant;

public class SpecialCharacter {
	public static final String EMPTY = "";
	public static final String SPACE = " ";
}
