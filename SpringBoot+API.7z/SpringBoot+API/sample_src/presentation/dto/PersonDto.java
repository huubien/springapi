package vn.fujinet.sample.presentation.dto;

import lombok.Data;

@Data
public class PersonDto {
	private String name;
	private int age;
	private String address;
}
